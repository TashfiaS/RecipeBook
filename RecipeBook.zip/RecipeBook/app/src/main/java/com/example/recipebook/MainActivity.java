package com.example.recipebook;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.recipebook.Classes.RecyclerItemClickListener;

import java.util.ArrayList;

import Adapters.RecipeAdapter;
import Models.RecipeModel;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recycleView);
        ArrayList<RecipeModel> list=new ArrayList<>();
        list.add(new RecipeModel(R.drawable.food1, "Burger"));
        list.add(new RecipeModel(R.drawable.food2, "Pizza "));
        list.add(new RecipeModel(R.drawable.food3, "Biriyani "));
        list.add(new RecipeModel(R.drawable.food4, "Cake "));
        list.add(new RecipeModel(R.drawable.food5, " Ice Cream "));

        RecipeAdapter adapter= new RecipeAdapter(list,  this );
        recyclerView.setAdapter(adapter);
        StaggeredGridLayoutManager staggered = new StaggeredGridLayoutManager( 2, StaggeredGridLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(staggered);

        recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(
                this, recyclerView, new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                switch (position){
                    case 0:
                        Intent intent=new Intent(MainActivity.this, ScrollingActivity.class);
                        startActivity(intent);
                        break;
                    case 1:
                        Intent intent=new Intent(MainActivity.this, PizzaActivity.class);
                        startActivity(intent);
                        break;
                    case 2:
                        Toast.makeText(MainActivity.this, "Third Item is clicked", Toast.LENGTH_SHORT).show();
                        break;
                    case 3:
                        Toast.makeText(MainActivity.this, "Fourth Item is clicked", Toast.LENGTH_SHORT).show();
                        break;
                    case 4:
                        Toast.makeText(MainActivity.this, "Fifth Item is clicked", Toast.LENGTH_SHORT).show();
                        break;
                    default:
                }

            }

            @Override
            public void onLongItemClick(View view, int position) {
                switch (position){
                    case 0:
                        Toast.makeText(MainActivity.this, "First Item is clicked", Toast.LENGTH_SHORT).show();
                        break;
                    case 1:
                        Toast.makeText(MainActivity.this, "Second Item is clicked", Toast.LENGTH_SHORT).show();
                        break;
                    case 2:
                        Toast.makeText(MainActivity.this, "Third Item is clicked", Toast.LENGTH_SHORT).show();
                        break;
                    case 3:
                        Toast.makeText(MainActivity.this, "Fourth Item is clicked", Toast.LENGTH_SHORT).show();
                        break;
                    case 4:
                        Toast.makeText(MainActivity.this, "Fifth Item is clicked", Toast.LENGTH_SHORT).show();
                        break;

                    default:
                }


            }
        }

        ));
    }
}